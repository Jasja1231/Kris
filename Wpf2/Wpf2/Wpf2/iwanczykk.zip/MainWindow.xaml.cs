﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Canvas> slides = new List<Canvas>();
        Random r = new Random();
        public MainWindow()
        {
            InitializeComponent();
        }

        private SolidColorBrush get_brush()
        {
            int red = r.Next(0, 255);
            int blue = r.Next(0, 255);
            int green = r.Next(0, 255);
            SolidColorBrush brush = new SolidColorBrush(Color.FromRgb((byte)red,(byte)blue,(byte)green));
            return brush;
        }
        private void new_presentation(object sender, RoutedEventArgs e)
        {
            panel.Children.Clear();
            slides.Clear();
        }
        private void show_presentation(object sender, RoutedEventArgs e)
        {
                if (panel.Children.Count==0)
                    MessageBox.Show(this,"error","error", MessageBoxButton.OK , MessageBoxImage.Error);
                else 
                {
                    this.WindowState = System.Windows.WindowState.Maximized;
                    this.WindowStyle = System.Windows.WindowStyle.None;
                    this.Cursor = Cursors.None;
                    if (!(slides.Count == 0))
                    {
                        box.Child = slides.ElementAt(0);
                        box.Visibility = Visibility.Visible;
                    }
                }
        }
        private void add_slide(object sender, RoutedEventArgs e)
        {
            Canvas c = new Canvas();
            c.Width = 550;
            c.Height = 400;
            c.Background = get_brush();
            panel.Children.Add(c);
            Canvas copy = new Canvas();
            copy.Width = 550;
            copy.Height = 400;
            copy.Background = c.Background;
            slides.Add(copy);

        }

    }
}
